import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
  selector: 'login-form',
  templateUrl: './login-form.component.html',
})

export class LoginForm {
  @Input() user: string = '';
  @Input() email: string = '';
  @Input() password: string = '';
  @Input() loginTo: string = '';
  @Input() linkLogin: string = '';
  // @Output() handleLogin = new EventEmitter<string>();

  onLogin() {

  }
}