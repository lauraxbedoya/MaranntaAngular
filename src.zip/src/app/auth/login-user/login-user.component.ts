import { Component, OnInit } from "@angular/core"
import { UserService } from "src/services/user.service"
import { Router } from '@angular/router';
import { storeUser } from "src/app/store/session.actions";
import { SessionStateType } from "src/app/store/session.reducer";
import { Observable } from "rxjs";
import { select, Store } from "@ngrx/store";
import { AppState, selectSession, selectSessionUserInfo } from "src/app/store";
import { AdminType, UserType } from "src/utils/types";
import storage, { AUTH_TOKEN } from "src/utils/storage";

@Component({
  selector: 'login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.styles.css']
  })

  export class LoginUser {
    email: string = "sashamaria@hotmail.com";
    password: string = "password123";
    messageError: string = "Todos los campos son requeridos";

  constructor(
    private _userService: UserService,
    private router: Router,
    private store: Store<AppState>
  ) {}
  
  async handleLogin() {
    if (!this.validateForm()) return;

    (await this._userService.login(this.email, this.password))
      .subscribe((data: {accessToken: string, user: any}) => {
        this.store.dispatch(storeUser({ ...data.user, isAdmin: false }));
        storage.save(AUTH_TOKEN, data.accessToken);
        this.router.navigate(['/']);
      })    
  }

  validateForm(): boolean {
    if(!this.email || !this.password) {
      alert(this.messageError)
      return false
    }
    return true
  }
}