import { Component } from "@angular/core";
import { UserType } from "src/utils/types";

@Component({
  selector: 'sign-up',
  templateUrl: './sign-up.component.html'
})

export class SignUp {
  genderList: string[] = ["Seleccionar...","Masculino", "Femenino"];

  isCheckedOffers: boolean = false;
  isCheckedPolitics: boolean = false;

  name: string = "";
  lastname: string = "";
  email: string = "";
  password: string = "";
  confirmPassword: string = "";
  dateOfBirth: string = "";
  gender: string = "";
  offers: boolean = false;
  politics: boolean = true;
}