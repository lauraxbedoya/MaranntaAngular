import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginAdmin } from './auth/login-admin/login-admin.component';
import { LoginUser } from './auth/login-user/login-user.component';
import { SignUp } from './auth/signUp/sign-up.component';

const routes: Routes = [
  { path: 'user/login', component: LoginUser },
  { path: 'admin/login', component: LoginAdmin },
  { path: 'user/registration', component: SignUp },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
